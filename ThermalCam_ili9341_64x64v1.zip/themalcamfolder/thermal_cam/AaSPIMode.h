//this seperate file is the only way i can keep seperate the different driver modes
#ifndef _SPIMODE
#define _SPIMODE
//#include "SPIxx.h"
#include <SPI.h> 
#define spi_mode  1 //set this to 1 if using internal <spi> set to 0 if using "SPIxx.h"
 #endif
