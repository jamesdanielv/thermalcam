//this seperate file is the only way i can keep seperate the different driver modes
#ifndef _thermalSensor
#define _thermalSensor
//0 for amg8833 8x8 sensor
//1 for mlx90460 32x24 sensor
#define Sensor_mode  0 //change this vale here. this setsup the libraries of code to use for specific sensors
 #endif
