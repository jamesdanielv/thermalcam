//this seperate file is the only way i can keep seperate the different driver modes
//this is lcd mode for checking and setting lcd mode
#define lcd_mode 1 //change this to 0 or 1
 //change settings in this file. this allows us to optimizw betweeb two display libaries without much other work. 0 =Adafruit_ST7735.h    1=Adafruit_ILI9341.tr

 
