//this seperate file is the only way i can keep seperate the different river modes
#ifndef _SPIMODE
#define _SPIMODE
#include "SPIxx.h"
//#include <SPI.h> 
#define spi_mode  0 //set this to 1 if using internal <spi> set to 0 if using "SPIxx.h"
 #endif
